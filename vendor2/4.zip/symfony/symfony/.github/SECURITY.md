Security Policy
===============

If you found any issues that might have security implications,
please send a report to security[at]symfony.com
DO NOT PUBLISH SECURITY REPORTS PUBLICLY.

The full [Security Policy][1] is described in the official documentation.

  [1]: https://symfony.com/security
