<?php

@trigger_error('I come from… afar! :D', E_USER_DEPRECATED);
