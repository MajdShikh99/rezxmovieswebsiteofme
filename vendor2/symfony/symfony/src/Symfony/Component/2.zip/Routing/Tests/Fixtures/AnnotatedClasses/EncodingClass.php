<?php

namespace Symfony\Component\Routing\Tests\Fixtures\AnnotatedClasses;

class EncodingClass
{
    public function routeÀction()
    {
    }
}
