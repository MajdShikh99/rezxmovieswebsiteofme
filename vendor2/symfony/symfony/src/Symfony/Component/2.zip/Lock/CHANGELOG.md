CHANGELOG
=========

3.4.0
-----

 * added the component
