<?php

namespace Gedmo\Sluggable\Util;

use Behat\Transliterator\Transliterator;

/**
 * Transliteration utility
 */
class Urlizer extends Transliterator
{
}
